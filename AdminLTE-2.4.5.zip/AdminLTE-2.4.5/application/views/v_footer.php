<footer class="main-footer" style="font-size: 12.5px;">
	<div class="pull-right hidden-xs">
	  <b>Version</b> <?php echo APP_VERSION; ?> || Page rendered in <strong>{elapsed_time}</strong> seconds
	</div><?= COPY_RIGHT; ?>
</footer>