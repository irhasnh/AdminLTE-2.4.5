<!-- daterange picker -->
<link href="<?= base_url();?>assets/plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">