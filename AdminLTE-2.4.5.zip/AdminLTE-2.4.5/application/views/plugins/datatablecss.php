<!-- DATA TABLES CSS -->
<link href="<?= base_url();?>assets/plugins/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">        
<link href="<?= base_url();?>assets/plugins/datatables/dataTables.responsive.css" rel="stylesheet">    
<link href="<?= base_url();?>assets/plugins/datatables/dataTables.tableTools.min.css" rel="stylesheet">