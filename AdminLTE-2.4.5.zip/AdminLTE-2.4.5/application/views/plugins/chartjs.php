<!-- ChartJS -->
<script src="<?= base_url(); ?>assets/plugins/chart.js/Chart.js"></script>