<!-- Select2 -->
<script src="<?= base_url(); ?>assets/plugins/select2/dist/js/select2.full.min.js"></script>
