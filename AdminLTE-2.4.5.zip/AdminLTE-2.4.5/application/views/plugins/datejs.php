<!-- bootstrap datepicker -->
<script src="<?= base_url();?>assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>