<!-- DATA TABLES JS -->
<script src="<?= base_url();?>assets/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url();?>assets/plugins/datatables/dataTables.tableTools.js"></script>
<script src="<?= base_url();?>assets/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url();?>assets/plugins/datatables/dataTables.responsive.min.js"></script>
<!-- SCRIPT JS KOMBIN -->
<script src="<?= base_url();?>assets/pages/js_kombin.js"></script>