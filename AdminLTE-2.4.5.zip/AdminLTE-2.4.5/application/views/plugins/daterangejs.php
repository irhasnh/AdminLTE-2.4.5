<!-- date-range-picker -->
<script src="<?= base_url();?>assets/plugins/moment/min/moment.min.js"></script>
<script src="<?= base_url();?>assets/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>