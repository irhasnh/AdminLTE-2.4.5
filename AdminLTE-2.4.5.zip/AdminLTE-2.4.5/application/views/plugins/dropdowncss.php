<!-- Select2 -->
<link href="<?= base_url(); ?>assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet">