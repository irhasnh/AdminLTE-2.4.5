<!-- iCheck for checkboxes and radio inputs -->
<link href="<?= base_url(); ?>assets/plugins/iCheck/all.css" rel="stylesheet">